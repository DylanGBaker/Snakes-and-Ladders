main.cpp will run the game.
Player.h contains the player class.
Player.cpp contains the functions declared in Player.h and their algorithms.
Board.h contains the functions that make the board from the user input in input.txt.
GameHandler.h contains the dice roll function and the function for the game loop.

All of these files are needed for the program to work correctly as main.cpp uses them.